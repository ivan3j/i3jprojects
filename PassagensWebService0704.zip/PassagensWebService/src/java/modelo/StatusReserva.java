package modelo;

public enum StatusReserva {

	aberta,emAndamento,efetivada,cancelada;
}
